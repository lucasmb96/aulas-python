import os
os.system('cls')

numero = int(input('Introduza numero 0 - 20: '))

numeros = 'zero','um', 'dois', 'tres', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezasseis', 'dezassete', 'dezoito', 'dezanove', 'vinte'

print(f'{numeros[numero]}')