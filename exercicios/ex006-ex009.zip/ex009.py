km = input("km")
dias = input("dias")
# 60e dia e 0.456km

precodia = 60.0 * float(dias)
precokm = 0.456 * float(km)
total = precodia + precokm

print(total)
