var1 = input("number1:")
var2 = input("number2:")
var3 = input("number3:")
var4 = input("number4:")
var5 = input("number5:")

media = (float(var1) + float(var1)+ float(var1) + float(var1) + float(var1))/5 

print(media)