var1 = input("number:")
var2 = input("number:")

soma = int(var1) + int(var2)
sub = int(var1) - int(var2)
mullti = int(var1) * int(var2)
div = int(var1) / int(var2)
resto = int(var1) % int(var2)

print(soma, sub, mullti, div, resto)
