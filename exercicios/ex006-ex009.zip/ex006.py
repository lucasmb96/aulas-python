var = input("number:")


print(int(var), int(var)+1, int(var)-1)