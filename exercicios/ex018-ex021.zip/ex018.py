import os
import time

os.system('cls')

for t in range(10,0,-1):
    print(t)
    time.sleep(1)

print('0')