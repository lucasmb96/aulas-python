print('--- Calculadora ---')
print('[ 1 ] – Tabuada')
print('[ 2 ] – Calculadora')
print('[ 3 ] – Fatorial')
print('[ 4 ] – Números primos')

opcao = input('--> ')
print('Escolheste a opção:', opcao)