name = input("Digite o nome:")
print('Olá,', name+'. Damos boas vindas ao nosso programa.\n')
