nome = input('nome: ').strip()

print(nome.upper())
print(nome.lower())
print(len(nome.replace(' ','')))

print(int(nome.find(' ')))

